
import './myComponents/Pages/Pages.css';
import Navbar from './myComponents/Pages/Navbar'
function App() {
  return (
    <div>
      <Navbar/>
    </div>
  );
}

export default App;
