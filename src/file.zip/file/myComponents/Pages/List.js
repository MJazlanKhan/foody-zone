export const FoodList = [
    {
        createdAt: "2023-08-11T12:23:42.642Z",
        name: "similique",
        imageUrl: "https://loremflickr.com/640/480/food&quot",
        price: "904.00",
        description:
            "Necessitatibus fugit illum veniam. Ipsam magni iure aspernatur. Voluptas rem similique. Debitis reiciendis sunt delectus impedit vitae quis unde aut.",
        id: "1",
        type: "breakfast",
    },
    {
        createdAt: "2023-08-11T20:47:26.014Z",
        name: "sunt",
        imageUrl: "https://loremflickr.com/640/480/food&quot",
        price: "233.00",
        description:
            "Repellendus nihil ullam eaque. Ducimus expedita cumque. Aspernatur numquam debitis assumenda. Quaerat at optio necessitatibus accusamus reprehenderit distinctio officiis ullam repudiandae. Dignissimos eius nesciunt vitae consequuntur corrupti velit dolorum ratione excepturi. Mollitia rem sapiente voluptates voluptate corporis.",
        id: "2",
        type: "breakfast",
    },
    {
        createdAt: "2023-08-11T18:25:39.249Z",
        name: "corporis",
        imageUrl: "https://loremflickr.com/640/480/food&quot",
        price: "765.00",
        description:
            "Accusamus voluptate dolorem laborum sunt et eius. Ab qui porro fugiat cumque nostrum nesciunt quod. Ad libero est delectus atque dicta mollitia sit nisi eligendi. Ut omnis quam provident totam facilis.",
        id: "3",
        type: "breakfast",
    },
    {
        createdAt: "2023-08-11T17:10:35.321Z",
        name: "facilis",
        imageUrl: "https://loremflickr.com/640/480/food&quot",
        price: "117.00",
        description:
            "Cupiditate aspernatur quam fugit rem aut officiis quos. Deleniti cupiditate debitis saepe. Explicabo nostrum cupiditate laudantium quod ipsum earum provident. Placeat qui assumenda repellat laboriosam. Nam nobis unde aliquam. Tempora quos aliquam commodi harum.",
        id: "4",
        type: "breakfast",
    },
    {
        createdAt: "2023-08-12T07:57:04.043Z",
        name: "rem",
        imageUrl: "https://loremflickr.com/640/480/food&quot",
        price: "830.00",
        description:
            "Eum sit earum aut. Laborum at nobis. Sequi distinctio ad commodi suscipit voluptates harum reiciendis expedita. Qui voluptates accusamus modi hic sed.",
        id: "5",
        type: "breakfast",
    }]